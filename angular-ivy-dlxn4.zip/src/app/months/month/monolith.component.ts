import { Component, Input } from "@angular/core";

@Component({
  selector: "app-monolith",
  templateUrl: "./monolith.component.html",
  styleUrls: ["./monolith.component.scss"]
  // styleUrls: ["./month.component.scss"]
})
export class MonolithComponent {
  @Input() month;
}
